// Você precisa de dois loops aninhados para comparar cada número sorteado com cada número da cartela. nos acertos

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(void){
    int i, j, c;
    int c1[10], c2[10], c3[10];
    int sorteio[10];
    int acertos1 = 0, num_acertos1[10];
    int acertos2 = 0, num_acertos2[10];
    int acertos3 = 0, num_acertos3[10];
    int num1, num_rep1[10];
    int num2, num_rep2[10];
    int num3, num_rep3[10];

    srand(time(NULL));

    printf("\n Cartela 1:  ");
    for(j=0; j<10; j++){
        c1[j] = rand () % 20;
        printf("%d ",  c1[j]);
    }
    printf("\n Cartela 2:  ");
    for(j=0; j<10; j++){
        c2[j] = rand () % 20;
        printf("%d ",  c2[j]);
    }
    printf("\n Cartela 3:  ");
    for(j=0; j<10; j++){
        c3[j] = rand () % 20;
        printf("%d ",  c3[j]);
    }
    printf("\n");

    printf("\n Sorteio: ");
    for(i=0; i<10; i++){
        sorteio[i]= rand () % 20;
        printf("%d ",  sorteio[i]);
    }
    printf("\n");

    printf("\n Acertos da cartela 1: ");
    for (j=0; j<10; j++){
        for(i=0; i<10; i++){
            if (c1[j] == sorteio[i]){
                while (c1[j] == c2[j] && c1[j] == c3[j]){
                    num_acertos1[acertos1] = c1[j];
                    acertos1++;
                    break;
                }
            }  
        }
    }
    for(j=0; j<acertos1; j++){
            printf("%d ",   num_acertos1[j]);
        }

    printf("\n Acertos da cartela 2: ");
    for(j=0; j<10; j++){
        for (i=0; i<10; i++){
            if (c2[j] == sorteio[i]){
                while(c2[j] == c3[j] && c2[j] == c1[j]){
                    num_acertos2[acertos2] = c2[j];
                    acertos2++;
                    break;
                }
            }

        }
    }
    for(j=0; j<acertos2; j++){
        printf("%d ",   num_acertos2[j]);
    }

    printf("\n Acertos da cartela 3: ");
    for(j=0; j<10; j++){
        for (i=0; i<10; i++){
            if (c3[j] == sorteio[i]){
                while(c3[j] == c1[j] && c3[j] == c2[j]){
                    num_acertos3[acertos3] = c3[j];
                    acertos3++;
                    break;
                }
            }
        }
    }
    for(j=0; j<acertos3; j++){
        printf("%d ",   num_acertos3[j]);
    }
}